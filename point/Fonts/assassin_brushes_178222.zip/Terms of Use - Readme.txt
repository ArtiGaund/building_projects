Assassin Brush Set - Grunge Abstract Brush Pack

Information:
Size of Brushes: +/- 1000 Pxls Width
Brushes Made By: ShiftyJ
Number of Brushes: 10
PS Version: CS1 - CS5

Rules:
- You may use these brushes for Personal use, credit is appreciated.
- You may NOT use these brushes for Commercial use without my permission. Contact me if needed. Via:

Site: 
http://shiftyj.deviantart.com/

Mail:
jacobknegtel@hotmail.com

Enjoy Brushing!

Twitter:
http://twitter.com/shiftygraphics